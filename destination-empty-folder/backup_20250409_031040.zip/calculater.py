# User input for two numbers, converted to integers
num1 = int(input("Enter num1: "))  
num2 = int(input("Enter num2: "))  

# Displaying the type of num1 to verify input conversion
print(type(num1))  

# Performing addition and displaying the result
sum_of_num = num1 + num2  
print("Result of sum is", sum_of_num)  

# Performing subtraction and displaying the result
sub_of_num = num1 - num2  
print("Result of sub is", sub_of_num)  

# Performing multiplication and displaying the result
mul_of_num = num1 * num2  
print("Result of mul is", mul_of_num)  

# Performing division and displaying the result
div_of_num = num1 / num2  
print("Result of div is", div_of_num)  